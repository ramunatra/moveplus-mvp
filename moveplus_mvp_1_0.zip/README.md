# Move+ MVP 1.0

Protótipo inicial em Flutter para Android.

## O que já funciona
- Escolha entre Passageiro e Motorista
- Passageiro informa origem/destino
- Solicitação simulada de corrida
- Motorista fica online/offline
- Motorista aceita uma corrida simulada
- Status básico da corrida

## Próximas etapas
1. Firebase/autenticação
2. Banco de dados de corridas
3. GPS e Google Maps
4. Corridas em tempo real entre dois celulares
5. Pagamentos Pix/cartão
6. Avaliações
7. Painel administrativo
8. Regras, contratos e requisitos legais antes do lançamento comercial
