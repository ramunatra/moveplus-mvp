import 'package:flutter/material.dart';

void main() {
  runApp(const MovePlusApp());
}

class MovePlusApp extends StatelessWidget {
  const MovePlusApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Move+',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Move+')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.directions_car, size: 80),
              const SizedBox(height: 16),
              const Text(
                'Move+',
                style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text('Seu transporte, sua cidade.'),
              const SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  icon: const Icon(Icons.person),
                  label: const Text('Entrar como passageiro'),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const PassengerPage()),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  icon: const Icon(Icons.drive_eta),
                  label: const Text('Entrar como motorista'),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const DriverPage()),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PassengerPage extends StatefulWidget {
  const PassengerPage({super.key});

  @override
  State<PassengerPage> createState() => _PassengerPageState();
}

class _PassengerPageState extends State<PassengerPage> {
  final origin = TextEditingController();
  final destination = TextEditingController();
  String status = 'Nenhuma corrida solicitada';

  @override
  void dispose() {
    origin.dispose();
    destination.dispose();
    super.dispose();
  }

  void requestRide() {
    if (origin.text.trim().isEmpty || destination.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Informe origem e destino.')),
      );
      return;
    }
    setState(() => status = 'Corrida solicitada — aguardando motorista');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Passageiro')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Para onde vamos?',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          TextField(
            controller: origin,
            decoration: const InputDecoration(
              labelText: 'Origem',
              prefixIcon: Icon(Icons.my_location),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: destination,
            decoration: const InputDecoration(
              labelText: 'Destino',
              prefixIcon: Icon(Icons.location_on),
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          Card(
            child: ListTile(
              leading: const Icon(Icons.payments),
              title: const Text('Estimativa'),
              subtitle: const Text('R\$ 20,00'),
              trailing: const Text('15%'),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: requestRide,
            child: const Text('SOLICITAR CORRIDA'),
          ),
          const SizedBox(height: 24),
          Text(status, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

class DriverPage extends StatefulWidget {
  const DriverPage({super.key});

  @override
  State<DriverPage> createState() => _DriverPageState();
}

class _DriverPageState extends State<DriverPage> {
  bool online = false;
  bool accepted = false;

  @override
  Widget build(BuildContext context) {
    final status = accepted
        ? 'Corrida aceita — passageiro aguardando'
        : online
            ? 'Você está online'
            : 'Você está offline';

    return Scaffold(
      appBar: AppBar(title: const Text('Motorista')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('Ficar disponível'),
              subtitle: Text(online ? 'Online' : 'Offline'),
              value: online,
              onChanged: (value) => setState(() => online = value),
            ),
            const SizedBox(height: 20),
            if (online && !accepted)
              Card(
                child: Column(
                  children: [
                    const ListTile(
                      leading: Icon(Icons.person_pin_circle),
                      title: Text('Nova solicitação'),
                      subtitle: Text('Centro → Jardim'),
                    ),
                    const Padding(
                      padding: EdgeInsets.all(16),
                      child: Text('Estimativa: R\$ 20,00'),
                    ),
                    FilledButton(
                      onPressed: () => setState(() => accepted = true),
                      child: const Text('ACEITAR CORRIDA'),
                    ),
                    const SizedBox(height: 12),
                  ],
                ),
              ),
            const SizedBox(height: 20),
            Text(status),
          ],
        ),
      ),
    );
  }
}
